<?php
// Implementasi Abstract Class dan Abstract Method PHP
abstract class User
{
abstract protected function showName();
// memiliki required argument: $greeting
abstract public function showGreeting($greeting);
}
class Admin extends User
{
public function showName()
{
return "Atok";
}
// memiliki required argument: $greeting
// dan opsional argument: $address
public function showGreeting($greeting, $address = 'Surabaya')
{
return $greeting . ", my name is " . $this->showName() . " from
" . $address;
}
}
$class = new Admin;
// output: Good morning, my name is Atok from Surabaya
echo $class->showGreeting("Good Evening");
?>