<?php
// Implementasi pembuatan dan pengaksesan Class
class Hello // class
{
public function print_hello()
{
echo "Hello World!";
}
}
$hello = new Hello();
$hello -> print_hello();
?>