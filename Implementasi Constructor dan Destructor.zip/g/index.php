<?php
// Implementasi Constructor dan Destructor
class laptop
{
private $pemilik = "Galang";
private $merk = "Macbook";
public function __construct()
{
echo "Ini berasal dari Constructor Laptop";
}
public function hidupkan_laptop()
{
return "Hidupkan Laptop $this->merk punya $this->pemilik";
}
public function __destruct()
{
echo "Ini berasal dari Destructor Laptop";
}
}
// buat objek dari class laptop (instansiasi)
$laptop_Galang= new laptop();
echo "<br />";
echo $laptop_Galang->hidupkan_laptop();
echo "<br />";
?>